package com.ssafy.happyhouse.model.mapper;

import com.ssafy.happyhouse.model.MemberDto;


public interface MemberMapper {
	MemberDto signin(String id, String pw);
	void signup(MemberDto member);
	void update(MemberDto member);
	void delete(String id);
	MemberDto getMember(String id);
}
