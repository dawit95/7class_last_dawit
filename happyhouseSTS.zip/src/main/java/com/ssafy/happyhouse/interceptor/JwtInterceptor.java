package com.ssafy.happyhouse.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.service.JwtService;
import com.ssafy.happyhouse.model.service.MemberService;

@Component
public class JwtInterceptor implements HandlerInterceptor {
	@Autowired
	private JwtService jwtService;
	@Autowired
	private MemberService memberService;
	private Logger logger = LoggerFactory.getLogger(JwtInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		System.out.println(request.getMethod() + " :" + request.getServletPath());
		
		// option 요청은 바로 통과시켜주자.
		if (request.getMethod().equals("OPTIONS")) {
			return true;
		} else {
			// request의 parameter에서 auth_token으로 넘어온 녀석을 찾아본다.
			// String token = request.getParameter("auth_token");
			String accessToken = request.getHeader("at-jwt-access-token");
			String refreshToken = request.getHeader("at-jwt-refresh-token");

			if (accessToken != null && accessToken.length() > 0) {
				// 유효한 토큰이면 진행, 그렇지 않으면 예외를 발생시킨다.
				if(refreshToken == null) {
					jwtService.checkValid(accessToken);
					logger.trace("엑세스토큰 사용 가능: {}", accessToken);
					return true;
				}else {
					jwtService.checkValid(refreshToken);
					logger.trace("리프레쉬토큰 사용 가능: {}", refreshToken);
					MemberDto member = jwtService.get(accessToken);
					if(refreshToken.equals(memberService.getToken(member.getId()))) {
						accessToken = jwtService.create(member, "access");
						response.setHeader("at-jwt-access-token", accessToken);
						logger.trace("엑세스토큰 재발급: {}", accessToken);
						return true;
					}else {
						throw new RuntimeException("리프레쉬 토큰이 DB정보와 일치하지 않습니다.");
					}
				}
			} else {
				throw new RuntimeException("엑세스 토큰이 없습니다.");
			}
		}
	}
}
