package com.ssafy.happyhouse.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.AddressService;
import com.ssafy.happyhouse.model.service.ApiService;
import com.ssafy.happyhouse.model.service.HouseService;

@RestController
@RequestMapping("/api")
public class ApiController {
	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

	@Autowired
	private AddressService addressService;
	@Autowired
	private HouseService houseService;
	@Autowired
	private ApiService apiService;

	@RequestMapping(value = "/house", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> getApiData() {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;		
		// 전국 아파트매매정보 DB 추가로직
		List<HouseInfoDto> apiList = new ArrayList<>();
		List<String> codes = addressService.getAllGugunCode();
		try {
			for(String code : codes) {
				apiList.addAll(apiService.getHouseApi(code, "202105")); // 21년 5월데이터 받기
//				apiList.addAll(apiService.getHouseApi(code, "202104")); // 21년 4월데이터 받기
//				apiList.addAll(apiService.getHouseApi(code, "202103")); // 21년 3월데이터 받기
//				apiList.addAll(apiService.getHouseApi(code, "202102")); // 21년 2월데이터 받기
//				apiList.addAll(apiService.getHouseApi(code, "202101")); // 21년 1월데이터 받기
			}
		} catch (XPathExpressionException | IOException | SAXException | ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("크기 : " + apiList.size());
		
		houseService.insertHouse(apiList);
		System.out.println("insert완료");
		
    	resultMap.put("msg", "공공데이터 포털 API 작업 완료.");
    	status = HttpStatus.OK;
		
    	return new ResponseEntity<>(resultMap, status);
	}
	
}
