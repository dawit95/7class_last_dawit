package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.GoodService;

@CrossOrigin("*")
@RestController
@RequestMapping("/good")
public class GoodController {

	@Autowired
	private GoodService goodService;

	@RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> addGood(@RequestBody Map<String, String> paramMap,
			HttpServletRequest request) {
		Map<String, Object> resultMap = new HashMap<>();
		String sido = paramMap.get("sido");
		String gugun = paramMap.get("gugun");
		String dong = paramMap.get("dong");
		String aptName = paramMap.get("aptname");
		String jibun = paramMap.get("jibun");
		String buildYear = paramMap.get("buildyear");
		String memberId = request.getAttribute("memberId").toString();
		HttpStatus status = null;
		
		int check = goodService.checkGood(sido, gugun, dong, aptName, jibun, buildYear, memberId);
		
		if(check > 0) {
        	resultMap.put("msg", "이미 좋아요를 하였습니다.");
        	status = HttpStatus.BAD_REQUEST;
		}else if(check == 0){
	        if(goodService.addGood(sido, gugun, dong, aptName, jibun, buildYear, memberId) > 0) {
	        	resultMap.put("msg", "좋아요 성공");
	        	status = HttpStatus.OK;
	        }else {
	        	resultMap.put("msg", "좋아요 실패.");
	        	status = HttpStatus.BAD_REQUEST;
	        }
		}else {
			resultMap.put("msg", "입력값이 올바르지 않습니다.");
			status = HttpStatus.BAD_REQUEST;
		}
        return new ResponseEntity<>(resultMap, status);
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> deleteGood(@RequestBody Map<String, String> paramMap,
			HttpServletRequest request) {
		Map<String, Object> resultMap = new HashMap<>();
		String sido = paramMap.get("sido");
		String gugun = paramMap.get("gugun");
		String dong = paramMap.get("dong");
		String aptName = paramMap.get("aptname");
		String jibun = paramMap.get("jibun");
		String buildYear = paramMap.get("buildyear");
		String memberId = request.getAttribute("memberId").toString();
		HttpStatus status = null;
		
		int check = goodService.checkGood(sido, gugun, dong, aptName, jibun, buildYear, memberId);
		
		if(check > 0) {
	        if(goodService.deleteGood(sido, gugun, dong, aptName, jibun, buildYear, memberId) > 0) {
	        	resultMap.put("msg", "좋아요 취소 성공");
	        	status = HttpStatus.OK;
	        }else {
	        	resultMap.put("msg", "좋아요 취소 실패.");
	        	status = HttpStatus.BAD_REQUEST;
	        }
		}else if(check == 0){
        	resultMap.put("msg", "좋아요 한 상태가 아닙니다.");
        	status = HttpStatus.BAD_REQUEST;
		}else {
			resultMap.put("msg", "입력값이 올바르지 않습니다.");
			status = HttpStatus.BAD_REQUEST;
		}
        return new ResponseEntity<>(resultMap, status);
	}

	@RequestMapping(value = "/mylist", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> myGoodList(HttpServletRequest request) {
		Map<String, Object> resultMap = new HashMap<>();
		String memberId = request.getAttribute("memberId").toString();
		HttpStatus status = null;
		List<HouseInfoDto> list = goodService.myGoodList(memberId);
        resultMap.put("mylist", list);
    	status = HttpStatus.OK;
		return new ResponseEntity<>(resultMap, status);
	}

	@RequestMapping(value = "/idlist", method = RequestMethod.POST)
	public ResponseEntity<Map<String, Object>> getGoodIdList(@RequestBody Map<String, String> paramMap) {
		Map<String, Object> resultMap = new HashMap<>();
		String sido = paramMap.get("sido");
		String gugun = paramMap.get("gugun");
		String dong = paramMap.get("dong");
		String aptName = paramMap.get("aptname");
		String jibun = paramMap.get("jibun");
		String buildYear = paramMap.get("buildyear");
		HttpStatus status = null;
		List<String> list = goodService.getGoodIdList(sido, gugun, dong, aptName, jibun, buildYear);
        resultMap.put("idlist", list);
    	status = HttpStatus.OK;
		return new ResponseEntity<>(resultMap, status);
	}

}
