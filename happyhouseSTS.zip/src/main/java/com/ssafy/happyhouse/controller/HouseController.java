package com.ssafy.happyhouse.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.HouseService;

@RestController
@RequestMapping("/apt")
public class HouseController {
	private static final Logger logger = LoggerFactory.getLogger(HouseController.class);
	
	@Autowired
	private HouseService houseService;
	
	
	// response entity로 변경 예정
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public ResponseEntity<List<HouseInfoDto>> getHouse(@RequestParam(value="dong") String dong) {
		ResponseEntity<List<HouseInfoDto>> entity = null;
		List<HouseInfoDto> list = houseService.getHouse(dong);
		if(list.isEmpty()) {
			System.out.println("DB에 정보 없음, 공공 데이터 API와 연동 필요");
			// 연동 로직
		}
		entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
		
	@RequestMapping(value = "/option", method = RequestMethod.POST)
	public ResponseEntity<List<HouseInfoDto>> getHouseOption(@RequestBody Map<String,String> paramMap) {
		ResponseEntity<List<HouseInfoDto>> entity = null;

		String dong = paramMap.get("dong");
		String area = paramMap.get("area");
		String startPrice = paramMap.get("startprice");
		String endPrice = paramMap.get("endprice");
		String startDate = paramMap.get("startdate");
		String endDate = paramMap.get("enddate");
		String name = paramMap.get("name");
		
		if(area == null || area == "") {
			area = "0";
		}
		
		if(startPrice == null || startPrice == "" || endPrice == null || endPrice == "") {
			startPrice = "0";
			endPrice = "9999999999";
		}
		
		if(startDate == null || startDate == "" || endDate == null || endDate == "") {
			startDate = "00000000";
			endDate = "99999999";
		}else {
			startDate += "00";
			endDate += "99";
		}
		
		List<HouseInfoDto> list = houseService.getHouseOption(dong, Integer.parseInt(area),  Integer.parseInt(startPrice),  Integer.parseInt(endPrice), startDate, endDate, name);
		if(list.isEmpty()) {
			System.out.println("DB에 정보 없음, 공공 데이터 API와 연동 필요");
			// 연동 로직
		}
		entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
}
