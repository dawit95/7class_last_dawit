package com.ssafy.happyhouse.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.HouseService;

@RestController
@RequestMapping("/apt")
public class HouseController {
	private static final Logger logger = LoggerFactory.getLogger(HouseController.class);

	@Autowired
	private HouseService houseService;

	@RequestMapping(value = "/option", method = RequestMethod.POST)
	public ResponseEntity<List<HouseInfoDto>> getHouseOption(@RequestBody Map<String, Object> paramMap) {
		String dong = paramMap.get("dong").toString();
		ArrayList<Integer> area = (ArrayList<Integer>) paramMap.get("area");
		ArrayList<Integer> price = (ArrayList<Integer>) paramMap.get("price");
		String name = paramMap.get("name").toString();

		ResponseEntity<List<HouseInfoDto>> entity = null;
		List<HouseInfoDto> list = houseService.getHouseOption(dong, area.get(0), area.get(1), price.get(0), price.get(1), name);
		entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}

	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> getHouseDetail(@RequestParam(value = "no") int no) {
		Map<String, Object> resultMap = new HashMap<>();
		List<HouseInfoDto> list = houseService.getHouseDetail(no);
		Comparator<HouseInfoDto> comparator = Comparator.comparingInt(HouseInfoDto::getDealAmount);
		HouseInfoDto maxHouse = list.stream().max(comparator).orElseThrow(NoSuchElementException::new);
		HouseInfoDto minHouse = list.stream().min(comparator).orElseThrow(NoSuchElementException::new);
		resultMap.put("list", list);
		resultMap.put("max", maxHouse.getDealAmount());
		resultMap.put("min", minHouse.getDealAmount());
		return new ResponseEntity<Map<String, Object>>(resultMap, HttpStatus.OK);
	}
}
