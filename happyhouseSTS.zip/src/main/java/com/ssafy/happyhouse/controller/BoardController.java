package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.happyhouse.model.AddressDto;
import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.service.BoardService;
import com.ssafy.happyhouse.model.service.JwtService;
import com.ssafy.happyhouse.model.service.MemberService;

@CrossOrigin("*")
@RestController
@RequestMapping("/board")
public class BoardController {
	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value = "/read", method = RequestMethod.GET)
    public ResponseEntity<Map<String, Object>> read(@RequestParam(value = "no") int no) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(boardService.addView(no) > 0) {
    		BoardDto readBoard = boardService.read(no);
            resultMap.put("data", readBoard);
        	status = HttpStatus.OK;
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
		return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> write(@RequestBody BoardDto board) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(boardService.write(board) > 0) {
        	resultMap.put("msg", "게시글 작성 성공");
        	status = HttpStatus.OK;
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
		return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> update(@RequestBody BoardDto board) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(boardService.update(board) > 0) {
        	resultMap.put("msg", "게시글 수정 성공");
        	status = HttpStatus.OK;
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(resultMap,  status);
    }
	
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public ResponseEntity<Map<String, Object>> delete(@RequestParam(value = "no") int no) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(boardService.delete(no) > 0) {
        	resultMap.put("msg", "게시글 삭제 성공");
        	status = HttpStatus.OK;
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
		return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/all", method = RequestMethod.GET)
    public ResponseEntity<Map<String, Object>> getBoards() {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
		List<BoardDto> boardlist = boardService.getBoards();
        resultMap.put("boardlist", boardlist);
    	status = HttpStatus.OK;
		return new ResponseEntity<>(resultMap, status);
	}
	
//	@RequestMapping(value = "/all", method = RequestMethod.GET)
//    public ResponseEntity<List<BoardDto>> getBoards() {
//		ResponseEntity<List<BoardDto>> entity = new ResponseEntity<>(boardService.getBoards(), HttpStatus.OK);
//		return entity;
//	}
	
}
