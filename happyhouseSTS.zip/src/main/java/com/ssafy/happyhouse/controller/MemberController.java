package com.ssafy.happyhouse.controller;


import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.service.JwtService;
import com.ssafy.happyhouse.model.service.MemberService;

@CrossOrigin("*")
@RestController
@RequestMapping("/member")
public class MemberController {
    @Autowired
    private JwtService jwtService;
	@Autowired
	private MemberService memberService;

	@RequestMapping(value = "/signin", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> signin(@RequestBody Map<String, String> map, HttpServletResponse res) {
        Map<String, Object> resultMap = new HashMap<>();
        MemberDto loginMember = memberService.signin(map.get("id"), map.get("pw"));
        if(loginMember == null) {
            resultMap.put("msg", "아이디 또는 비밀번호가 틀렸습니다.");
        	return new ResponseEntity<Map<String, Object>>(resultMap, HttpStatus.UNAUTHORIZED);
        }
        
        // 로그인 성공했다면 토큰을 생성한다.
        String accessToken = jwtService.create(loginMember, "access");
        String refreshToken = jwtService.create(loginMember, "refresh");
        // refresh토큰을 DB에 업데이트 한다.
        memberService.updateToken(map.get("id"), refreshToken);
        // 토큰 정보는 request의 헤더로 보내고 나머지는 Map에 담아주자.
        res.setHeader("at-jwt-access-token", accessToken);
        res.setHeader("at-jwt-refresh-token", refreshToken);
        // resultMap.put("auth_token", token);
        resultMap.put("status", true);
        resultMap.put("data", loginMember);
        return new ResponseEntity<Map<String, Object>>(resultMap, HttpStatus.OK);
    }
	
	
	@RequestMapping(value = "/signup", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> signup(@RequestBody MemberDto member) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
		if(memberService.signup(member) > 0) {
			resultMap.put("msg", member.getId() + " 회원가입 성공");
			status = HttpStatus.OK;
		}else {
			resultMap.put("msg", "입력값이 올바르지 않습니다.");
			status = HttpStatus.BAD_REQUEST;
		}
		return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
    public ResponseEntity<Map<String, Object>> update(@RequestBody MemberDto member, HttpServletResponse res) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(memberService.update(member) > 0) {
        	resultMap.put("msg", member.getId() + " 회원수정 성공");
        	status = HttpStatus.OK;
        	// 업데이트 한 정보로 토큰 재발급
        	String accessToken = jwtService.create(member, "access");
            res.setHeader("at-jwt-access-token", accessToken);
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
        return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public ResponseEntity<Map<String, Object>> delete(@RequestParam(value = "id") String id) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(memberService.delete(id) > 0) {
        	resultMap.put("msg", id + " 회원삭제 성공");
        	status = HttpStatus.OK;
        }else {
        	resultMap.put("msg", "입력값이 올바르지 않습니다.");
        	status = HttpStatus.BAD_REQUEST;
        }
		return new ResponseEntity<>(resultMap, status);
    }
	
	@RequestMapping(value = "/checkid", method = RequestMethod.GET)
    public ResponseEntity<Map<String, Object>> checkId(@RequestParam(value = "id") String id) {
		Map<String, Object> resultMap = new HashMap<>();
		HttpStatus status = null;
        if(memberService.checkId(id) > 0) {
        	resultMap.put("msg", "이미 존재하는 ID입니다.");
        	status = HttpStatus.BAD_REQUEST;
        }else {
        	resultMap.put("msg", "사용 가능한 ID입니다.");
        	status = HttpStatus.OK;
        }
		return new ResponseEntity<>(resultMap, status);
    }
	
}
