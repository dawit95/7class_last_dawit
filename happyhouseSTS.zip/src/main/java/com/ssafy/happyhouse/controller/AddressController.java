package com.ssafy.happyhouse.controller;


import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.happyhouse.model.AddressDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.AddressService;
import com.ssafy.happyhouse.model.service.ApiService;
import com.ssafy.happyhouse.model.service.HouseService;

@RestController
@RequestMapping("/address")
public class AddressController {
	private static final Logger logger = LoggerFactory.getLogger(AddressController.class);

	@Autowired
	private AddressService addressService;
	@Autowired
	private HouseService houseService;
	@Autowired
	private ApiService apiService;

	@RequestMapping(value = "/sido", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> sido() {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getSido(), HttpStatus.OK);
		return entity;
	}

	@RequestMapping(value = "/gugun", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> gugun(@RequestParam(value = "sido") String sido) {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getGugunInSido(sido), HttpStatus.OK);
		return entity;
	}

	@RequestMapping(value = "/dong", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> dong(@RequestParam(value = "gugun") String gugun) {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getDongInGugun(gugun), HttpStatus.OK);
		return entity;
	}
	
	@RequestMapping(value = "/apt", method = RequestMethod.GET)
	public ResponseEntity<List<HouseInfoDto>> getHouse(@RequestParam(value = "sido") String sido, @RequestParam(value = "gugun") String gugun, @RequestParam(value = "dong") String dong) {
		ResponseEntity<List<HouseInfoDto>> entity = null;
		List<HouseInfoDto> list = houseService.getHouse(sido, gugun, dong);
		entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
}
