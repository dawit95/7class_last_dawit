package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.happyhouse.model.AddressDto;
import com.ssafy.happyhouse.model.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {
	private static final Logger logger = LoggerFactory.getLogger(AddressController.class);
	
	@Autowired
	private AddressService addressService;
	
	@RequestMapping(value = "/sido", method = RequestMethod.GET)
	public Object sido() {
		try {
			List<AddressDto> list = addressService.getSido();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return "시도목록을 얻어오는 중 문제가 발생했습니다.";
		}
	}
	
	@RequestMapping(value = "/gugun", method = RequestMethod.GET)
	public Object gugun(@RequestParam(value="sido") String sido) {
		try {
			System.out.println(sido);
			List<AddressDto> list = addressService.getGugunInSido(sido);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return "구군목록을 얻어오는 중 문제가 발생했습니다.";
		}
	}
	
	@RequestMapping(value = "/dong", method = RequestMethod.GET)
	public Object dong(@RequestParam(value="gugun") String gugun) {
		try {
			List<AddressDto> list = addressService.getDongInGugun(gugun);
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return "동목록을 얻어오는 중 문제가 발생했습니다.";
		}
	}
	
//	@RequestMapping(value = "/apt", method = RequestMethod.GET)
//	public Object apt(@RequestParam(value="dong") String dong) {
//		try {
//			List<HouseInfoDto> list = houseMapService.getAptInDong(dong);
//			return list;
//		} catch (Exception e) {
//			e.printStackTrace();
//			return "아파트목록을 얻어오는 중 문제가 발생했습니다.";
//		}
//	}
}
