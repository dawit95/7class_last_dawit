package com.ssafy.happyhouse.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ssafy.happyhouse.model.AddressDto;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.service.AddressService;
import com.ssafy.happyhouse.model.service.HouseService;

@RestController
@RequestMapping("/address")
public class AddressController {
	private static final Logger logger = LoggerFactory.getLogger(AddressController.class);

	@Autowired
	private AddressService addressService;
	@Autowired
	private HouseService houseService;

	@RequestMapping(value = "/sido", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> sido() {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getSido(), HttpStatus.OK);
		return entity;
	}

	@RequestMapping(value = "/gugun", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> gugun(@RequestParam(value = "sido") String sido) {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getGugunInSido(sido), HttpStatus.OK);
		return entity;
	}

	@RequestMapping(value = "/dong", method = RequestMethod.GET)
	public ResponseEntity<List<AddressDto>> dong(@RequestParam(value = "gugun") String gugun) {
		ResponseEntity<List<AddressDto>> entity = new ResponseEntity<>(addressService.getDongInGugun(gugun), HttpStatus.OK);
		return entity;
	}
	
	@RequestMapping(value = "/apt", method = RequestMethod.GET)
	public ResponseEntity<List<HouseInfoDto>> getHouse(@RequestParam(value = "sido") String sido, @RequestParam(value = "gugun") String gugun, @RequestParam(value = "dong") String dong) {
		ResponseEntity<List<HouseInfoDto>> entity = null;
		List<HouseInfoDto> list = houseService.getHouse(sido, gugun, dong);
//		if(list.isEmpty()) {
//			System.out.println("DB에 정보 없음, 공공 데이터 API와 연동 필요");
//			// 연동 로직
//		}

		// 전국 아파트매매정보 DB 추가로직
//		List<HouseInfoDto> apiList = new ArrayList<>();
//		List<String> codes = addressService.getAllGugunCode();
//		try {
//			for(String code : codes) {
//				apiList.addAll(apiService.getHouseApi(code, "202103"));
//			}
//		} catch (XPathExpressionException | IOException | SAXException | ParserConfigurationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		System.out.println("크기 : " + apiList.size());
//		
//		houseService.insertHouse(apiList);
//		System.out.println("insert완료");

		entity = new ResponseEntity<>(list, HttpStatus.OK);
		return entity;
	}
	
}
