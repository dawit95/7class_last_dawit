package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;


public interface HouseMapper {
	List<HouseInfoDto> getHouse(String dong);
	List<HouseInfoDto> getHouseOption(String dong, int area, int startPrice, int endPrice, String startDate, String endDate, String name);
	
}
