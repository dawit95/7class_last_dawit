package com.ssafy.happyhouse.model.service;

import java.util.List;
import com.ssafy.happyhouse.model.AddressDto;

public interface AddressService {
	
	List<AddressDto> getSido();
	List<AddressDto> getGugunInSido(String sido);
	List<AddressDto> getDongInGugun(String gugun);
	List<String> getAllGugunCode(); // 서울 제외
}
