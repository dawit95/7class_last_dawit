package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.AddressDto;

public interface AddressService {
	
	List<AddressDto> getSido() throws Exception;
	List<AddressDto> getGugunInSido(String sido) throws Exception;
	List<AddressDto> getDongInGugun(String gugun) throws Exception;
//	List<HouseInfoDto> getAptInDong(String dong) throws Exception;
	
}
