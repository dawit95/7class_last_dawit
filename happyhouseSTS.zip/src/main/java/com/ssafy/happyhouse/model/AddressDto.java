package com.ssafy.happyhouse.model;

public class AddressDto {

	private String sidoName;
	private String gugunName;
	private String dongName;
//	private String sidoCode;
//	private String dongCode;
//	private String gugunCode;

	public String getSidoName() {
		return sidoName;
	}

	public void setSidoName(String sidoName) {
		this.sidoName = sidoName;
	}

	public String getGugunName() {
		return gugunName;
	}

	public void setGugunName(String gugunName) {
		this.gugunName = gugunName;
	}
	

	public String getDongName() {
		return dongName;
	}

	public void setDongName(String dongName) {
		this.dongName = dongName;
	}
	
//	public String getSidoCode() {
//		return sidoCode;
//	}
//
//	public void setSidoCode(String sidoCode) {
//		this.sidoCode = sidoCode;
//	}
//	
//	public String getGugunCode() {
//		return gugunCode;
//	}
//
//	public void setGugunCode(String gugunCode) {
//		this.gugunCode = gugunCode;
//	}
//	
//	public String getDongCode() {
//		return dongCode;
//	}
//
//	public void setDongCode(String DongCode) {
//		this.dongCode = dongCode;
//	}	

}
