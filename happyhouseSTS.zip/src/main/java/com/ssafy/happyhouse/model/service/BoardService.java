package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.BoardDto;

public interface BoardService {
	BoardDto read(int no);
	int write(BoardDto board);
	int update(BoardDto board);
	int delete(int no);
	int addView(int no);
	List<BoardDto> getBoards();
}
