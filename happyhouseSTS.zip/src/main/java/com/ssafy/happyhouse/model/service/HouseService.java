package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;

public interface HouseService {
	List<HouseInfoDto> getHouse(String dong) throws Exception;
	List<HouseInfoDto> getHouseOption(String dong, int area, int startPrice, int endPrice, String startDate, String endDate, String name) throws Exception;
	
}
