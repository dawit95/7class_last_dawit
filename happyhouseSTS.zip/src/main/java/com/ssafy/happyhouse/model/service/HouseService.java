package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;

public interface HouseService {
	List<HouseInfoDto> getHouse(String sido, String gugun, String dong);
	List<HouseInfoDto> getHouseOption(String sido, String gugun, String dong, int startArea, int endArea, int startPrice, int endPrice, String name);
	List<HouseInfoDto> getHouseDetail(int no);
	int insertHouse(List<HouseInfoDto> houses); // 공공데이터 API연동용
}
