package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.AddressDto;
import com.ssafy.happyhouse.model.mapper.AddressMapper;

@Service
public class AddressServiceImpl implements AddressService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<AddressDto> getSido(){
		return sqlSession.getMapper(AddressMapper.class).getSido();
	}

	@Override
	public List<AddressDto> getGugunInSido(String sido){
		return sqlSession.getMapper(AddressMapper.class).getGugunInSido(sido);
	}

	@Override
	public List<AddressDto> getDongInGugun(String gugun){
		return sqlSession.getMapper(AddressMapper.class).getDongInGugun(gugun);
	}
	
	@Override
	public List<String> getAllGugunCode(){
		return sqlSession.getMapper(AddressMapper.class).getAllGugunCode();
	}

}
