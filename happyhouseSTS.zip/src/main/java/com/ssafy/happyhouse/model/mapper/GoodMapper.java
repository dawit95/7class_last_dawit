package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.HouseInfoDto;

public interface GoodMapper {
	int addGood(String dong, String aptName, String jibun, String buildYear, String memberId);
	List<HouseInfoDto> myGoodList(String memberId);
	List<String> getGoodIdList(String dong, String aptName, String jibun, String buildYear); 
}
