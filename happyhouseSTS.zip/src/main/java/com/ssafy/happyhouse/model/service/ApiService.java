package com.ssafy.happyhouse.model.service;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.xml.sax.SAXException;

import com.ssafy.happyhouse.model.HouseInfoDto;

public interface ApiService {
	List<HouseInfoDto> getHouseApi(String code, String date) throws IOException, SAXException, ParserConfigurationException, XPathExpressionException;
}
