package com.ssafy.happyhouse.model.service;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.mapper.HouseMapper;

@Service
public class HouseServiceImpl implements HouseService {
	
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public List<HouseInfoDto> getHouse(String dong){
		return sqlSession.getMapper(HouseMapper.class).getHouse(dong);
	}

	@Override
	public List<HouseInfoDto> getHouseOption(String dong, int startArea, int endArea, int startPrice, int endPrice, String name){
		return sqlSession.getMapper(HouseMapper.class).getHouseOption(dong, startArea, endArea, startPrice, endPrice, name);
	}
	
	@Override
	public List<HouseInfoDto> getHouseDetail(int no){
		return sqlSession.getMapper(HouseMapper.class).getHouseDetail(no);
	}
	
	@Override
	public int insertHouse(List<HouseInfoDto> houses) {
		return sqlSession.getMapper(HouseMapper.class).insertHouse(houses);
	}
}
