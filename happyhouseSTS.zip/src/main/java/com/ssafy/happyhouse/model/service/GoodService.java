package com.ssafy.happyhouse.model.service;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;

public interface GoodService {
	int addGood(String sido, String gugun, String dong, String aptName, String jibun, String buildYear, String memberId);
	int deleteGood(String sido, String gugun, String dong, String aptName, String jibun, String buildYear, String memberId);
	List<HouseInfoDto> myGoodList(String memberId);
	List<String> getGoodIdList(String sido, String gugun, String dong, String aptName, String jibun, String buildYear);
	int checkGood(String sido, String gugun, String dong, String aptName, String jibun, String buildYear, String memberId);
}
