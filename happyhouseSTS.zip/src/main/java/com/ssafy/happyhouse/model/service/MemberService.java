package com.ssafy.happyhouse.model.service;

import com.ssafy.happyhouse.model.MemberDto;

public interface MemberService {
	MemberDto signin(String id, String pw);
	int signup(MemberDto member);
	int update(MemberDto member);
	int delete(String id);
	MemberDto getMember(String id);
}
