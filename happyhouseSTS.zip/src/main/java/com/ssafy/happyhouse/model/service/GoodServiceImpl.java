package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.mapper.GoodMapper;

@Service
public class GoodServiceImpl implements GoodService {
	@Autowired
	private SqlSession sqlSession;

	@Override
	public int addGood(String sido, String gugun, String dong, String aptName, String jibun, String buildYear, String memberId) {
		if (!StringUtils.hasText(sido) || !StringUtils.hasText(gugun) || !StringUtils.hasText(dong) || !StringUtils.hasText(aptName) || !StringUtils.hasText(jibun)
				|| !StringUtils.hasText(buildYear) || !StringUtils.hasText(memberId)) {
			return -1;
		}
		return sqlSession.getMapper(GoodMapper.class).addGood(sido, gugun, dong, aptName, jibun, buildYear, memberId);
	}

	@Override
	public List<HouseInfoDto> myGoodList(String memberId) {
		if (!StringUtils.hasText(memberId)) {
			return null;
		}
		return sqlSession.getMapper(GoodMapper.class).myGoodList(memberId);
	}

	@Override
	public List<String> getGoodIdList(String sido, String gugun, String dong, String aptName, String jibun, String buildYear) {
		if (!StringUtils.hasText(sido) || !StringUtils.hasText(gugun) || !StringUtils.hasText(dong) || !StringUtils.hasText(aptName) || !StringUtils.hasText(jibun)
				|| !StringUtils.hasText(buildYear)) {
			return null;
		}
		return sqlSession.getMapper(GoodMapper.class).getGoodIdList(sido, gugun, dong, aptName, jibun, buildYear);
	}
}
