package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.mapper.BoardMapper;
import com.ssafy.happyhouse.model.mapper.GoodMapper;

public class GoodServiceImpl implements GoodService {
	@Autowired
	private SqlSession sqlSession;

	@Override
	public int addGood(String dong, String aptName, String jibun, String buildYear, String memberId) {
		if (!StringUtils.hasText(dong) || !StringUtils.hasText(aptName) || !StringUtils.hasText(jibun)
				|| !StringUtils.hasText(buildYear) || !StringUtils.hasText(memberId)) {
			return -1;
		}
		return sqlSession.getMapper(GoodMapper.class).addGood(dong, aptName, jibun, buildYear, memberId);
	}

	@Override
	public List<HouseInfoDto> myGoodList(String memberId) {
		if (!StringUtils.hasText(memberId)) {
			return null;
		}
		return sqlSession.getMapper(GoodMapper.class).myGoodList(memberId);
	}

	@Override
	public List<String> getGoodIdList(String dong, String aptName, String jibun, String buildYear) {
		if (!StringUtils.hasText(dong) || !StringUtils.hasText(aptName) || !StringUtils.hasText(jibun)
				|| !StringUtils.hasText(buildYear)) {
			return null;
		}
		return sqlSession.getMapper(GoodMapper.class).getGoodIdList(dong, aptName, jibun, buildYear);
	}
}
