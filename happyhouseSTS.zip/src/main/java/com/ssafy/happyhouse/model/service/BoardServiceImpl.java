package com.ssafy.happyhouse.model.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.mapper.BoardMapper;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public BoardDto read(int no) {
		return sqlSession.getMapper(BoardMapper.class).read(no);
	}
	
	@Override
	public int write(BoardDto board) {
		String title = board.getTitle();
		String id = board.getAuthorId();
		if(!StringUtils.hasText(title) || !StringUtils.hasText(id)) {
			return -1;
		}
		return sqlSession.getMapper(BoardMapper.class).write(board);
	}
	
	@Override
	public int update(BoardDto board) {
		String title = board.getTitle();
		if(!StringUtils.hasText(title)) {
			return -1;
		}
		return sqlSession.getMapper(BoardMapper.class).update(board);
	}
	
	@Override
	public int delete(int no) {
		return sqlSession.getMapper(BoardMapper.class).delete(no);
	}
	
	@Override
	public int addView(int no) {
		return sqlSession.getMapper(BoardMapper.class).addView(no);
	}
}
