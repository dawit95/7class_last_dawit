package com.ssafy.happyhouse.model.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.mapper.MemberMapper;

@Service
public class MemberServiceImpl  implements MemberService{
	@Autowired
	private SqlSession sqlSession;

	@Override
	public MemberDto signin(String id, String pw){
		return sqlSession.getMapper(MemberMapper.class).signin(id, pw);
	}
	
	@Override
	public void signup(MemberDto member){
		sqlSession.getMapper(MemberMapper.class).signup(member);
	}
	
	@Override
	public void update(MemberDto member){
		sqlSession.getMapper(MemberMapper.class).update(member);
	}
	
	@Override
	public void delete(String id){
		sqlSession.getMapper(MemberMapper.class).delete(id);
	}
	
	@Override
	public MemberDto getMember(String id){
		return sqlSession.getMapper(MemberMapper.class).getMember(id);
	}

}
