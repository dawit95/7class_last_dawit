package com.ssafy.happyhouse.model.service;

import org.apache.ibatis.session.SqlSession;
import org.springframework.util.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.mapper.MemberMapper;

@Service
public class MemberServiceImpl  implements MemberService{
	@Autowired
	private SqlSession sqlSession;

	@Override
	public MemberDto signin(String id, String pw){
		if(!StringUtils.hasText(id) || !StringUtils.hasText(pw)) {
			return null;
		}
		return sqlSession.getMapper(MemberMapper.class).signin(id, pw);
	}
	
	@Override
	public int signup(MemberDto member){
		String id = member.getId();
		String pw = member.getPw();
		if(!StringUtils.hasText(id) || !StringUtils.hasText(pw)) {
			return -1;
		}
		return sqlSession.getMapper(MemberMapper.class).signup(member);
	}
	
	@Override
	public int update(MemberDto member){
		String id = member.getId();
		String pw = member.getPw();
		if(!StringUtils.hasText(id) || !StringUtils.hasText(pw)) {
			return -1;
		}
		return sqlSession.getMapper(MemberMapper.class).update(member);
	}
	
	@Override
	public int delete(String id){
		if(!StringUtils.hasText(id)) {
			return -1;
		}
		return sqlSession.getMapper(MemberMapper.class).delete(id);
	}
	
	@Override
	public int checkId(String id){
		if(!StringUtils.hasText(id)) {
			return 0;
		}
		return sqlSession.getMapper(MemberMapper.class).checkId(id);
	}

}
