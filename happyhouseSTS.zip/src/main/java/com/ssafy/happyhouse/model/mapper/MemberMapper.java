package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.MemberDto;


public interface MemberMapper {
	MemberDto signin(String id, String pw);
	int signup(MemberDto member);
	int update(MemberDto member);
	int delete(String id);
	int checkId(String id);
	List<BoardDto> getBoards();
}
