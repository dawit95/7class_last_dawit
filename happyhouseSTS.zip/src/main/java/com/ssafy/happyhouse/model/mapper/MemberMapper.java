package com.ssafy.happyhouse.model.mapper;

import com.ssafy.happyhouse.model.MemberDto;


public interface MemberMapper {
	MemberDto signin(String id, String pw);
	int signup(MemberDto member);
	int update(MemberDto member);
	int delete(String id);
	MemberDto getMember(String id);
}
