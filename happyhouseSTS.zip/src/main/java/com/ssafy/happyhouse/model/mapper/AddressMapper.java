package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.HouseInfoDto;
import com.ssafy.happyhouse.model.AddressDto;


public interface AddressMapper {

	List<AddressDto> getSido();
	List<AddressDto> getGugunInSido(String sido);
	List<AddressDto> getDongInGugun(String gugun);
	
}
