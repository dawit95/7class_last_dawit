package com.ssafy.happyhouse;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.ssafy.happyhouse.interceptor.JwtInterceptor;


@Configuration
public class WebConfig implements WebMvcConfigurer{
    @Autowired
    private JwtInterceptor jwtInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtInterceptor).addPathPatterns("/**")
        .excludePathPatterns(Arrays.asList("/member/**"))
        .excludePathPatterns(Arrays.asList("/address/**"))
        .excludePathPatterns(Arrays.asList("/apt/option"));
//        .excludePathPatterns(Arrays.asList("/notice/getTotalCount"))
//        .excludePathPatterns(Arrays.asList("/qna/list"));
    }
    
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
        .allowedOrigins("*")
        .allowedMethods("*")
        .allowedHeaders("*")
        .exposedHeaders("at-jwt-access-token", "at-jwt-refresh-token");
    }
}
