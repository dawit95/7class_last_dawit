package com.ssafy.happyhouse.advice;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.service.JwtService;

@ControllerAdvice
public class RestControllerAdvice implements ResponseBodyAdvice<Object>{
	@Autowired
	private JwtService jwtService;
	
	@Override
	public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
		System.out.println(returnType.getExecutable().getDeclaringClass());
		return true;
	}
	
	@Override
	public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
		if (!request.getMethod().equals("OPTIONS")) {
			HttpHeaders header = request.getHeaders();
			if(header.get("jwt-auth-token") != null && body.getClass().getSimpleName().equals("HashMap")) {
				String token = header.get("jwt-auth-token").get(0);
//				if (StringUtils.hasText(token)) {
				MemberDto member = jwtService.get(token);
				System.out.println(member.getId());
				System.out.println(member.getType());
				HashMap<String, Object> map = (HashMap<String, Object>) body;
				map.put("usertype", member.getType());
				body = map;
//				}
			}
			System.out.println(body.getClass().getSimpleName());
		}
		return body;
	}
}
