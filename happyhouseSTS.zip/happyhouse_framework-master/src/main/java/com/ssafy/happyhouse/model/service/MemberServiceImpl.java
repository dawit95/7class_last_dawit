package com.ssafy.happyhouse.model.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.mapper.MemberMapper;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public void registerMember(MemberDto memberDto) {
		sqlSession.getMapper(MemberMapper.class).registerMember(memberDto);
	}

	@Override
	public MemberDto login(Map<String, String> map) throws Exception {
		if(map.get("userid") == null || map.get("userpwd") == null)
			return null;
		return sqlSession.getMapper(MemberMapper.class).login(map);
	}

	@Override
	public MemberDto getMember(String userId) {
		return sqlSession.getMapper(MemberMapper.class).getMember(userId);
	}

	@Override
	public void modifyMember(MemberDto memberDto) {
		sqlSession.getMapper(MemberMapper.class).modifyMember(memberDto);
	}

	@Override
	public void deleteMember(String userId) {
		sqlSession.getMapper(MemberMapper.class).deleteMember(userId);
	}

}
