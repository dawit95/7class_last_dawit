package com.ssafy.happyhouse.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.happyhouse.model.MemberDto;
import com.ssafy.happyhouse.model.service.MemberService;

@Controller
public class MemberController {

	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "/sign-in", method = RequestMethod.GET)
	public String signin() {
		return "sign-in";
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public String profile() {
		return "profile";
	}
	
	@RequestMapping(value = "/profile/modify", method = RequestMethod.GET)
	public String profileModify() {
		return "profile-modify";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@RequestParam("user-log") String userid, @RequestParam("password-log") String userpwd, Model model, HttpSession session, HttpServletResponse response) {
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("userid", userid);
		map.put("userpwd", userpwd);
		
		try {
			MemberDto memberDto = memberService.login(map);
			
			if(memberDto != null) {
				session.setAttribute("userinfo", memberDto);
			} else {
				model.addAttribute("loginMsg", "아이디 또는 비밀번호를 확인해주세요");
				return "index";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "로그인 중 문제가 발생했습니다.");
			return "error/error";
		}
		
		return "redirect:/";
	}
	
}
