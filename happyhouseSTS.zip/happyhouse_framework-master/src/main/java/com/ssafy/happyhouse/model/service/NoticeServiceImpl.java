package com.ssafy.happyhouse.model.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.model.NoticeDto;
import com.ssafy.happyhouse.model.mapper.NoticeMapper;

@Service
public class NoticeServiceImpl implements NoticeService {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public void insertNotice(NoticeDto noticeDto) throws Exception {
		sqlSession.getMapper(NoticeMapper.class).insertNotice(noticeDto);
	}

	@Override
	public List<NoticeDto> listNotice(String word) throws Exception {
		return sqlSession.getMapper(NoticeMapper.class).listNotice(word);
	}

	@Override
	public NoticeDto getNotice(int noticeNo) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyNotice(NoticeDto noticeDto) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteNotice(int noticeNo) throws Exception {
		// TODO Auto-generated method stub

	}



}
