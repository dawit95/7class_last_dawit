package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.NoticeDto;

public interface NoticeMapper {

//	공지등록
	void insertNotice(NoticeDto noticeDto) throws Exception;
	
//	공지목록
	List<NoticeDto> listNotice(String word) throws Exception;
	
//	공지조회
	NoticeDto getNotice(int noticeNo) throws Exception;
	
//	공지수정
	void modifyNotice(NoticeDto noticeDto) throws Exception;
	
//	공지삭제
	void deleteNotice(int noticeNo) throws Exception;
	
}
