-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema happyhouse
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema happyhouse
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `happyhouse` DEFAULT CHARACTER SET utf8 ;
USE `happyhouse` ;

-- -----------------------------------------------------
-- Table `happyhouse`.`member`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `happyhouse`.`member` ;

CREATE TABLE IF NOT EXISTS `happyhouse`.`member` (
  `userid` VARCHAR(16) NOT NULL,
  `userpwd` VARCHAR(16) NOT NULL,
  `username` VARCHAR(20) NOT NULL,
  `email` VARCHAR(50) NULL,
  `phone` VARCHAR(16) NULL,
  `joindate` TIMESTAMP NULL DEFAULT current_timestamp,
  PRIMARY KEY (`userid`))
ENGINE = InnoDB;

INSERT INTO member (userid, userpwd, username, email, phone)
VALUES('admin', 'admin', '관리자', 'admin@ssafy.com','010-0000-0000');

INSERT INTO member (userid, userpwd, username, email, phone)
VALUES('ssafy', 'ssafy', '김싸피', 'ssafy@ssafy.com','010-0000-0000');

commit;

-- -----------------------------------------------------
-- Table `happyhouse`.`notice`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `happyhouse`.`notice` ;

CREATE TABLE IF NOT EXISTS `happyhouse`.`notice` (
  `noticeno` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(100) NOT NULL,
  `content` VARCHAR(2000) NOT NULL,
  `postdate` TIMESTAMP NULL DEFAULT current_timestamp,
  `views` INT NOT NULL default 0,
  INDEX `happyhouse_noticeno_FK_idx` (`noticeno` ASC) VISIBLE,
  PRIMARY KEY (`noticeno`))
ENGINE = InnoDB;

INSERT INTO notice (title, content, views)
VALUES('HappyHouse 사이트 오픈!', '사이트 오픈했습니다', 856);

INSERT INTO notice (title, content, views)
VALUES('금주의 업데이트 안내', '백엔드 기능이 추가됐습니다', 1838);

INSERT INTO notice (title, content, views)
VALUES('HappyHouse 오픈 기념 이벤트', '추첨을 통해 테슬라 모델 3를 드립니다.', 1756);

commit;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
