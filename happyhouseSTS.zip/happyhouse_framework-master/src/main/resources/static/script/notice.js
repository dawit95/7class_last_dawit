// 글쓰기 유효성 검사
function writeNotice(form, root) {
  // 제목 유효성 검사
  if (!$(form.title).val()) {
    alert('제목을 입력하세요.');
    $(form.title).focus();
    return;
  }
  // 내용 유효성 검사
  if (!$(form.content).val()) {
    alert('내용을 입력하세요.');
    $(form.content).focus();
    return;
  }
  $(form).attr("action", root + '/main');
  $(form).submit();
  alert('게시글이 작성 되었습니다!!!');
}