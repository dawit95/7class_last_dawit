//--------------------------추가한 내용-----------------------------
$(document).ready(function () {
  // 로그인한 회원정보가 있는지 확인
  var user = localStorage.getItem('user');

  // 회원정보가 있다면 상태변경
  if (user) {
    var data = JSON.parse(user);
    //    $('#guest').hide();
    //    $('#user').show();
    $('.has_submenu').css('display', '');

    // 회원정보 반영
    var profile = $('#user-profile').find('.profile');
    var userphone = data.phone;
    if (userphone.length == 11) {
      userphone = userphone.replace(/(\d{3})(\d{4})(\d{4})/, '$1-$2-$3');
    } else if (userphone.length == 10) {
      userphone = userphone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
    }
    var profileHTML = `
	  <li class="disabled"><span>아이디</span> ${data.id}</li>
	  <li>
		<span>비밀번호</span> &bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;
	  </li>
	  <li><span>이름</span> ${data.name}</li>
	  <li>
		<span>이메일</span>
		${data.email}
	  </li>
	  <li>
		<span>휴대폰번호</span>
		${userphone}
	  </li>
	  `;
    profile.html(profileHTML);

    // 회원정보 수정 반영
    var modify = $('.modify-user').find('.profile');
    var modifyHTML = `
	  <li class="disabled"><span>아이디</span> ${data.id}</li>
	  <li>
		<span>비밀번호</span> <input
		type="password"
		placeholder="비밀번호를 입력하세요."
		name="pwd"
		class="form-control"
		id="pwd"
		maxlength="16"
	  />
	  </li>
	  <li><span>이름</span> <input
	  type="text"
	  placeholder="이름을 입력하세요."
	  name="name"
	  id="name"
	  class="form-control input-inline margin-right"
	  value="${data.name}"
	/></li>
	  <li>
		<span>이메일</span> <input
		type="text"
		placeholder="이메일 주소를 입력하세요."
		name="email"
		class="form-control input-inline"
		id="email"
		value="${data.email}"
	  /></li>
	  <li>
		<span>휴대폰번호</span> <input
		type="tel"
		placeholder="휴대폰번호를 입력하세요."
		name="phone"
		class="form-control input-inline"
		id="phone"
		maxlength="16"
		value="${data.phone}"
	  />
	  </li>
	  `;
    modify.html(modifyHTML);
  } else {
    //    $('#guest').show();
    //    $('#user').hide();
  }
});

// 로그인 버튼을 눌렀을 때
function login() {
  var id = $('#user-log').val();
  var pwd = $('#password-log').val();
  if (!id) {
    alert('아이디를 입력해주세요.');
    $('#user-log').focus();
    return;
  }
  if (!pwd) {
    alert('비밀번호를 입력해주세요.');
    $('#password-log').focus();
    return;
  }

  $('#loginform').submit();
}

// 로그아웃
function logout() {
  var flag = confirm('로그아웃 하시겠습니까?');
  if (flag) {
    localStorage.removeItem('user');
    location.href = 'index.html';
  }
}

/* 회원가입 유효성 검사 */
function checkForm(form, root) {
  // 아이디 유효성 검사
  if (!$(form.id).val()) {
    alert('아이디를 입력하세요.');
    $(form.id).focus();
    return;
  } else {
    // 아이디 중복 체크
    var flag = 'no';
    $.ajax({
      url: '../ajax/userlist.xml',
      type: 'GET',
      dataType: 'xml',
      async: false,
      success: function (response) {
        $(response)
          .find('id')
          .each(function () {
            if ($(this).text() == $(form.id).val()) {
              alert('이미 등록된 아이디입니다. 다른 아이디를 입력해주세요.');
              flag = 'yes';
              return;
            }
          });
      },
    });
    if (flag == 'yes') {
      return;
    }
  }
  // 비밀번호 유효성 검사
  if (!$(form.pwd).val()) {
    alert('비밀번호를 입력하세요.');
    $(form.pwd).focus();
    return;
  }
  if (!$(form.repwd).val()) {
    alert('비밀번호 확인을 입력하세요.');
    $(form.repwd).focus();
    return;
  }
  if ($(form.pwd).val() != $(form.repwd).val()) {
    alert('비밀번호와 비밀번호 확인이 다릅니다.');
    $(form.repwd).focus();
    return;
  }
  // 이름 유효성 검사
  if (!$(form.name).val()) {
    alert('이름을 입력하세요.');
    $(form.name).focus();
    return;
  }
  // 이메일 유효성 검사
  if (!$(form.email).val()) {
    alert('이메일을 입력하세요.');
    $(form.email).focus();
    return;
  }
  // 휴대폰 번호 유효성 검사
  if (!$(form.phone).val()) {
    alert('휴대폰 번호를 입력하세요.');
    $(form.phone).focus();
    return;
  }
  // 이용약관 동의 검사
  if (!$(form.agree).is(':checked')) {
    alert('이용약관에 동의해주세요.');
    $(form.agree).focus();
    return;
  }
  $(form).attr("action", root + '/member');
  $(form).submit();
  alert('가입이 완료 되었습니다!');
}


function checkModifyForm(form, root) {
  // 비밀번호 유효성 검사
  if (!$(form.pwd).val()) {
    alert('비밀번호를 입력하세요.');
    $(form.pwd).focus();
    return;
  }
  if (!$(form.repwd).val()) {
    alert('비밀번호 확인을 입력하세요.');
    $(form.repwd).focus();
    return;
  }
  if ($(form.pwd).val() != $(form.repwd).val()) {
    alert('비밀번호와 비밀번호 확인이 다릅니다.');
    $(form.repwd).focus();
    return;
  }
  // 이름 유효성 검사
  if (!$(form.name).val()) {
    alert('이름을 입력하세요.');
    $(form.name).focus();
    return;
  }
  // 이메일 유효성 검사
  if (!$(form.email).val()) {
    alert('이메일을 입력하세요.');
    $(form.email).focus();
    return;
  }
  // 휴대폰 번호 유효성 검사
  if (!$(form.phone).val()) {
    alert('휴대폰 번호를 입력하세요.');
    $(form.phone).focus();
    return;
  }
  $(form).attr("action", root + '/member');
  $(form).submit();
  alert('회원정보 수정이 완료 되었습니다!');
}

// 회원탈퇴
function deleteUser() {
  var flag = confirm('정말 탈퇴 하시겠습니까?');
  if (flag) {
    alert('탈퇴했습니다.');
    location.href = '/happyhouse/member?act=deletemember';
  }
}

function searchPwd() {
  var id = $('#recovery-id').val();
  var name = $('#recovery-name').val();
  var phone = $('#recovery-phone').val();
  if (!id) {
    alert('아이디를 입력해주세요.');
    $('#recovery-id').focus();
    return;
  }
  if (!name) {
    alert('이름을 입력해주세요.');
    $('#recovery-name').focus();
    return;
  }
  if (!phone) {
    alert('휴대폰번호를 입력해주세요.');
    $('#recovery-phone').focus();
    return;
  }
  // userlist와 값 비교하기
  var idFlag = '';
  var nameFlag = '';
  var phoneFlag = '';
  $.ajax({
    url: '../ajax/userlist.xml',
    type: 'GET',
    dataType: 'xml',
    async: false,
    success: function (response) {
      $(response)
        .find('user')
        .each(function () {
          if ($(this).find('id').text() == id) {
            idFlag = 'yes';
            if ($(this).find('name').text() == name) {
              nameFlag = 'yes';
            }
            if ($(this).find('phone').text() == phone) {
              phoneFlag = 'yes';
            }
            return;
          }
        });
    },
  });
  if (!idFlag) {
    alert('존재하지 않는 아이디입니다.');
    $('#recovery-id').focus();
    return;
  }
  if (!nameFlag) {
    alert('이름이 틀렸습니다.');
    $('#recovery-name').focus();
    return;
  }
  if (!phoneFlag) {
    alert('휴대폰번호가 틀렸습니다.');
    $('#recovery-phone').focus();
    return;
  }

  // 비밀번호 찾기 성공 - 메일 발송
  alert('이메일로 임시 비밀번호를 발송했습니다.');
  $('.login-modal').modal('hide');
  location.reload();
}