package com.ssafy.happyhouse.model.mapper;

import java.util.List;

import com.ssafy.happyhouse.model.BoardDto;
import com.ssafy.happyhouse.model.HouseInfoDto;

public interface BoardMapper {
	BoardDto read(int no);
	int write(BoardDto board);
	int update(BoardDto board);
	int delete(int no);
	int addView(int no);
	List<BoardDto> getBoards();
}
